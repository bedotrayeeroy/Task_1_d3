$(document).ready(function(){
     var get_data=[];
     get_data=JSON.parse(localStorage.getItem("list"));
    jQuery("#page_down").append('<div class="card text-center" id="data_pack">'+get_data[0].id +'<br>'+ get_data[0].first_name +'<br>' + get_data[0].last_name +'<br>'+ get_data[0].email+'</div>' );
         });
       
           
       
     





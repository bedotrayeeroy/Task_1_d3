$(document).ready(function(){
   $("#login").click(function(){
    
  var listofobj=[];
       $.ajax({
     url:"https://reqres.in/api/users",
     method:"GET"
       }).done(function(data){ 
 
        for(var i=0; i<data.data.length; i++){
          var person={
            id:data.data[i].id,
            email:data.data[i].email,
            first_name:data.data[i].first_name,
            last_name:data.data[i].last_name,
          };
            listofobj.push(person);
        }   
         localStorage.setItem('list',JSON.stringify(listofobj)); 
         window.location.href="dasbrd.html";   
});
       });
     
      });

 
  